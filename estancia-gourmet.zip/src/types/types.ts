export interface Prato {
  id: number;
  categoria: string;
  nome: string;
  descricao: string;
  ingredientes: string[];
  preparo: string;
  imagem: string;
}
